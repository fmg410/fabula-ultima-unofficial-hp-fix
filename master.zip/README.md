This is a fork of razage's system.

You can find the original repo here: https://github.com/razage/fabula-ultima-unofficial