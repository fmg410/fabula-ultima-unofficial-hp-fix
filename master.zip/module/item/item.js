export class FabulaUltimaItem extends Item {
    prepareData() {
        super.prepareData();

        const itemData = this;
        const actorData = this.actor || {};
        const system = itemData.system;
    }
}
